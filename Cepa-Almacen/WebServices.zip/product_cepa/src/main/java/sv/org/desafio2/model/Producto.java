package sv.org.desafio2.model;

public class Producto {
private int id; 
private String nombre;
private double precio;
private String Categoria;


//constructor
	public Producto() {
		
	}
	
	
	public Producto (int id, String nombre, String Categoria, double precio) {
		this.id=id;
		this.nombre=nombre;
		this.precio=precio;
		this.Categoria=Categoria;
	}
	
	
	//getter y setter para obtener y agregar informacion
	
	public int getId() {
	 return id;
	}
	
	public String getNombre() {
		 return nombre;

	}
	public double getPrecio() {
		 return precio;

	}
	
	public String getCategoria() {
		 return Categoria;

}
	
	//setter 
	public void setId(int id) {
		this.id=id;
	}
	
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	


	public void setCategoria(String Categoria) {
	this.Categoria=Categoria;
	}
	
	public void setPrecio(double precio) {
		this.precio=precio;
	}
	
	
}

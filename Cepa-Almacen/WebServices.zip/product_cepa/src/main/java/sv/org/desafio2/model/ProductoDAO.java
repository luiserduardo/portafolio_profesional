package sv.org.desafio2.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



//Clase para Data Access Object con los metodo para acceder a la base de datos
public class ProductoDAO extends AppConnection {
//Entenxion de clase AppConnection
	
	//Metodo para insertar datos, recibe el parametro de la clase
		public void insert(Producto elemento) throws SQLException {
			  connect();
			//conexion
			pstmt = conn.prepareStatement("insert into productos  ( Nombre, Categoria,Precio) values ( ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1,elemento.getNombre());
			pstmt.setString(2, elemento.getCategoria());
			pstmt.setDouble(3, elemento.getPrecio());
	      

			//pstmt.setString(4, elemento.getFecha());
					
	        int rowsInserted = pstmt.executeUpdate();
	        if (rowsInserted > 0) {
	        	 // Obteniendo las llaves generadas
	            ResultSet keys = pstmt.getGeneratedKeys();
	            if (keys.next()) {
	                int id = keys.getInt(1);
	                elemento.setId(id);
	            }
	        }else {
	            System.out.println("No se insertó ninguna fila.");
	        }
			
	        close();
		}
		
	
	
	//metodo para listas
	public ArrayList<Producto> findAll()  throws SQLException{
		//Objeto que rrepresenta una conexion
		connect();
		
		//Hacemos uso de stament para enviar instrucciones
		stmt = conn.createStatement();
		
		//el objeto stamente (para enviar instrucciones) y la consulta aejecutar
		resultSet = stmt.executeQuery("select * from productos");
		
		ArrayList<Producto> productos = new ArrayList();

		while(resultSet.next()) {
			Producto objeto = new Producto();
			objeto.setId(resultSet.getInt("id"));
			objeto.setNombre(resultSet.getString("Nombre"));
			objeto.setPrecio(resultSet.getDouble("Precio"));
			objeto.setCategoria(resultSet.getString("Categoria"));

			
			productos.add(objeto);
		}
		close();
		return productos;
	}
	
	
	public Producto findById(int id)  throws SQLException{
		//Objeto que rrepresenta una conexion
		Producto objeto = null;

		connect();
		
		//Hacemos uso de stament para enviar instrucciones
		pstmt = conn.prepareStatement("select * from productos where id= ?");
		pstmt.setInt(1,id);
		//el objeto stamente (para enviar instrucciones) y la consulta aejecutar
		resultSet = pstmt.executeQuery();
		
//Diferencia entre PreparedStatement y CreateStatement, ambas permiten ejecutar consultas solo que la primera es mas segura por aceptar paramtros
		ArrayList<Producto> productos = new ArrayList();

		while(resultSet.next()) {
			 objeto = new Producto();
			 objeto.setId(resultSet.getInt("id"));
				objeto.setNombre(resultSet.getString("Nombre"));
				objeto.setCategoria(resultSet.getString("Categoria"));
				objeto.setPrecio(resultSet.getDouble("Precio"));
			
				productos.add(objeto);
		}
		close();
		return objeto;
	}
 	
	public void delete(int id )throws SQLException {
		  connect();
	        pstmt = conn.prepareStatement("DELETE FROM productos WHERE id = ?");
	        pstmt.setInt(1, id);
	        pstmt.execute();
	        close();
	}
	
	public void update (Producto elemento)  throws SQLException {
	    connect();
        pstmt = conn.prepareStatement("UPDATE productos SET Nombre = ?, Categoria = ?, Precio = ? WHERE id = ?");
        pstmt.setString(1, elemento.getNombre());
        pstmt.setString(2, elemento.getCategoria());
        pstmt.setDouble(3, elemento.getPrecio());
        pstmt.setInt(4, elemento.getId());
        pstmt.executeUpdate();
        close();
	}
	
	
	
}

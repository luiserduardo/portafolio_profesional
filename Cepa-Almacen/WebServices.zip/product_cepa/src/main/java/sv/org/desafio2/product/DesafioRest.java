package sv.org.desafio2.product;

import java.util.List;
import java.sql.SQLException;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import sv.org.desafio2.model.Producto;
import sv.org.desafio2.model.ProductoDAO;

//Direccion relativa
@Path("productos")
public class DesafioRest {

	ProductoDAO productosDAO = new ProductoDAO();
	
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInstrumentos() throws SQLException{
    	List<Producto> productos = productosDAO.findAll();
        return Response.status(200).entity(productos).build();

    }
    
    //metodo post para insertar
    
@POST
@Produces(MediaType.APPLICATION_JSON)
public Response InsertarInstrumento(
       // @FormParam("id") int id,
		@FormParam("nombre") String nombre,
		@FormParam("categoria" )String categoria,
		@FormParam("precio") Double precio)
		//@FormParam("Fecha") String Fecha
				throws SQLException {
	
	Producto elemento = new Producto();
	
	if(nombre==null || precio<0 || categoria==null) {
		   return Response.status(Response.Status.BAD_REQUEST)
                   .entity("Datos inválidos: todos los campos deben ser válidos.")
                   .build();
	} else {
		
	
	try {
		//a java le afectan las mayusculas
		elemento.setNombre(nombre);
		elemento.setCategoria(categoria);
		elemento.setPrecio(precio);
		//elemento.setFecha(Fecha);
		productosDAO.insert(elemento);
		
		 return Response.status(200)
	             .header("Access-Control-Allow-Origin", "*")
	             .entity(elemento)
	             .build();
	}catch(NullPointerException e) {
        return Response.status(Response.Status.BAD_REQUEST).entity("Datos inválidos: " + e.getMessage()).build();
	}
	
	}
	
	
}

//Delete 
@POST
@Path("delete/{id}")
@Produces(MediaType.APPLICATION_JSON)
public Response EliminarInstrumento(@PathParam("id") int id) throws SQLException {
	
	Producto elemento = productosDAO.findById(id);
	if(elemento == null) {
		  return Response.status(404)
                  .header("Access-Control-Allow-Origin", "*")
                  .entity("no encontrado")
                  .build();

	}
	productosDAO.delete(id);
	
	 return Response.status(204)
             .header("Access-Control-Allow-Origin", "*")
             .entity("borrado")
             .build();
	
}

//actualizar 
@POST
@Produces(MediaType.APPLICATION_JSON)
@Path("{id}")
public Response updateInstrumento(
		@PathParam("id") int id,
        @FormParam("nombre") String nombre,
        @FormParam("categoria") String categoria,
        @FormParam("precio") Double precio) throws SQLException {
	
	Producto elemento = productosDAO.findById(id);
	if(elemento == null) {
		  return Response.status(404)
                .header("Access-Control-Allow-Origin", "*")
                .entity("no encontrado")
                .build();

	}
	
	if(nombre==null || precio<0) {
		   return Response.status(Response.Status.BAD_REQUEST)
                .entity("Datos inválidos: todos los campos deben ser válidos.")
                .build();
	} 
	
	elemento.setNombre(nombre);
	elemento.setCategoria(categoria);
	elemento.setPrecio(precio);
	productosDAO.update(elemento);
	
	  return Response.status(200)
              .header("Access-Control-Allow-Origin", "*")
              .entity(elemento)
              .build();
}



@GET
@Produces(MediaType.APPLICATION_JSON)
@Path("{id}")
public Response getConceptosById(@PathParam("id") int id) throws SQLException {
	Producto elemento = productosDAO.findById(id);
    if (elemento == null) {
        return Response.status(404)
                       .header("Access-Control-Allow-Origin", "*")
                       .entity("elemento no encontrado")
                       .build();
    }
    return Response.status(200)
                   .header("Access-Control-Allow-Origin", "*")
                   .entity(elemento)
                   .build();
}
	
}

	


